#include "Matrix.h"

namespace alice2 {

    // Matrix implementation is mostly header-only for performance
    // This file exists for potential future implementations that require
    // separate compilation (e.g., complex matrix operations, optimizations)

} // namespace alice2
